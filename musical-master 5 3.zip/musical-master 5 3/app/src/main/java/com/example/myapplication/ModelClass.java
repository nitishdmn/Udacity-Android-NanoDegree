package com.example.myapplication;

public class ModelClass {

    int imageRes;
    String title;
    String singer;

    public ModelClass() {
    }

    public ModelClass(int imageRes, String title, String singer) {
        this.imageRes = imageRes;
        this.title = title;
        this.singer = singer;
    }

    public int getImageRes() {
        return imageRes;
    }

    public void setImageRes(int imageRes) {
        this.imageRes = imageRes;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }
}

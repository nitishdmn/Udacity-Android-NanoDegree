package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class Current_Playing extends AppCompatActivity {


    Button homebutton, button;
    SeekBar seekBar;

    public void init1() {

        homebutton = (Button) findViewById(R.id.hb);
        homebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Current_Playing.this, Starting_page.class);
                startActivity(intent);
            }

        });

        button = (Button) findViewById(R.id.two);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }

        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.basic_layout);
        init1();
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        getSupportActionBar().setTitle("Current Playing");
    }
}

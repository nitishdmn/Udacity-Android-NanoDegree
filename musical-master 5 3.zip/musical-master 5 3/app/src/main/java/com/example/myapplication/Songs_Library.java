package com.example.myapplication;

import android.content.Intent;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Songs_Library extends AppCompatActivity implements ItemClickListener {

    Button h;
    List<ModelClass> modelClassList = new ArrayList<>();

    private RecyclerView recyclerView;
    private CustomAdapter customAdapter;
    private RecyclerView.LayoutManager layoutManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);


        ImageButton play = (ImageButton) findViewById(R.id.playButton);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Songs_Library.this, Current_Playing.class);
                startActivity(intent);
            }
        });
        getSupportActionBar().setTitle("Songs");

        prepareData();

        recyclerView = findViewById(R.id.recycler_view);
        customAdapter = new CustomAdapter(this, modelClassList);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(customAdapter);
        customAdapter.setItemClickListener(this);

    }

    private void prepareData() {
        ModelClass modelClass = new ModelClass(R.drawable.albtroz, "I am Albatraoz", "Aron Chupa");
        modelClassList.add(modelClass);

        modelClass = new ModelClass(R.drawable.badliar, "Bad Liar", "Imagine Dragons");
        modelClassList.add(modelClass);

        modelClass = new ModelClass(R.drawable.believer, "Believer", "Imagine Dragons");
        modelClassList.add(modelClass);

        modelClass = new ModelClass(R.drawable.gotit, "I want it, I got it", "Ariana Grande");
        modelClassList.add(modelClass);

        modelClass = new ModelClass(R.drawable.delicate, "Delicate", "Taylor Swift");
        modelClassList.add(modelClass);

        modelClass = new ModelClass(R.drawable.girls, "Girls like You", "Maroon5");
        modelClassList.add(modelClass);

        modelClass = new ModelClass(R.drawable.shape, "Shape of You", "Ed Shreen");
        modelClassList.add(modelClass);

    }

    @Override
    public void onClick1(View view, int position) {
        Intent intent = new Intent(Songs_Library.this, Current_Playing.class);
        startActivity(intent);

    }
}


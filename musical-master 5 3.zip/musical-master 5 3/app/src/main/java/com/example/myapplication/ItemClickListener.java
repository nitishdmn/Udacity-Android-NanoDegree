package com.example.myapplication;

import android.view.View;

public interface ItemClickListener {

    void onClick1(View view, int position);
}

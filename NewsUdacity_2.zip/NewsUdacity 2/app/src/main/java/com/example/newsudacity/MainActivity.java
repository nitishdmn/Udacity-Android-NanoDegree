package com.example.newsudacity;

import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<NewsModelClass>>, ItemClickListener {


    private RecyclerView recyclerView;
    private NewsRecyclerAdapter newsRecyclerAdapter;

    private int load = 1;

    private ProgressBar progressBar;

    private TextView noDataTextView;

    String urlNews = "";

    private List<NewsModelClass> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findIds();

        setAdapt();

        checkNet();

        Uri.Builder builder = new Uri.Builder();
        builder.scheme("http")
                .authority("content.guardianapis.com")
                .appendPath("search")
                .appendQueryParameter("q", "debates")
                .appendQueryParameter("show-tags", "contributor")
                .appendQueryParameter("api-key", "test");

        urlNews = builder.build().toString();
    }

    private void checkNet() {
        LoaderManager loaderManager = null;

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            noDataTextView.setVisibility(View.GONE);
            loaderManager = getLoaderManager();
            loaderManager.initLoader(load, null, MainActivity.this);
            progressBar.setVisibility(View.VISIBLE);
        } else {
            View progressBar = findViewById(R.id.progress_bar);
            progressBar.setVisibility(View.GONE);
            noDataTextView.setText(getString(R.string.check_net));
            noDataTextView.setVisibility(View.VISIBLE);
        }
    }

    private void setAdapt() {
        newsRecyclerAdapter = new NewsRecyclerAdapter(MainActivity.this, new ArrayList<NewsModelClass>());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

    }

    private void findIds() {
        recyclerView = findViewById(R.id.recycler_view);
        progressBar = findViewById(R.id.progress_bar);
        noDataTextView = findViewById(R.id.no_data_text_view);

    }

    @Override
    public Loader<List<NewsModelClass>> onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader<List<NewsModelClass>>(this) {
            @Override
            protected void onStartLoading() {
                forceLoad();
            }

            @Nullable
            @Override
            public List<NewsModelClass> loadInBackground() {
                if (urlNews == null) {
                    return null;
                }
                List<NewsModelClass> list = NewsUtil.fetchNewsData(urlNews);
                return list;
            }
        };
    }

    @Override
    public void onLoadFinished(Loader<List<NewsModelClass>> loader, List<NewsModelClass> data) {
        progressBar.setVisibility(View.GONE);
        if (data != null && !data.isEmpty()) {
            newsRecyclerAdapter = new NewsRecyclerAdapter(MainActivity.this, data);
            list = data;
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setItemAnimator(new DefaultItemAnimator());
            recyclerView.setAdapter(newsRecyclerAdapter);
            newsRecyclerAdapter.setItemClickListener(MainActivity.this);
        } else {
            noDataTextView.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<NewsModelClass>> loader) {
        loader.reset();
    }

    @Override
    public void openNews(View view, int position) {
        NewsModelClass newsModelClass = list.get(position);
        Uri newsUri = Uri.parse(newsModelClass.getNewsUrl());
        Intent webIntent = new Intent(Intent.ACTION_VIEW, newsUri);
        startActivity(webIntent);
    }
}

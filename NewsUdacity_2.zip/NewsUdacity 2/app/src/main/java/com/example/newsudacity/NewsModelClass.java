package com.example.newsudacity;

public class NewsModelClass {

    private String newsTitle;

    private String newsAuthor;

    private String newsDate;

    private String newsSection;

    private String newsUrl;

    public NewsModelClass(String newsTitle, String newsAuthor, String newsDate, String newsSection, String newsUrl) {
        this.newsTitle = newsTitle;
        this.newsAuthor = newsAuthor;
        this.newsDate = newsDate;
        this.newsSection = newsSection;
        this.newsUrl = newsUrl;
    }

    public String getNewsTitle() {
        return newsTitle;
    }

    public String getNewsAuthor() {
        return newsAuthor;
    }

    public String getNewsDate() {
        return newsDate;
    }

    public String getNewsSection() {
        return newsSection;
    }

    public String getNewsUrl() {
        return newsUrl;
    }
}

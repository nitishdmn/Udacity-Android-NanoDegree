package com.example.newsudacity;

import android.view.View;

public interface ItemClickListener {

    void openNews(View view, int position);

}

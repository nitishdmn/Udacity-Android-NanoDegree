package com.example.newsudacity;

import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class NewsUtil {
    public NewsUtil() {
    }

    public static List<NewsModelClass> fetchNewsData(String reqUrl) {
        URL url = null;
        String jsonResponse = null;

        try {
            url = new URL(reqUrl);
        } catch (MalformedURLException e) {
        }

        try {
            jsonResponse = makeHttpRequest(url);
        } catch (IOException e) {

        }

        return extractDataFromJson(jsonResponse);
    }

    private static String makeHttpRequest(URL url) throws IOException {
        String jsonResponse = null;
        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        if (url == null) {
            return jsonResponse;
        }

        try {

            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(10000);
            urlConnection.setConnectTimeout(1500);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            if (urlConnection.getResponseCode() == 200) {
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            }
        } catch (IOException e) {
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {
                inputStream.close();
            }
        }
        return jsonResponse;
    }

    private static String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();

        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null) {
                stringBuilder.append(line);
                line = reader.readLine();
            }
        }
        return stringBuilder.toString();
    }

    private static List<NewsModelClass> extractDataFromJson(String jsonResponse) {
        if (TextUtils.isEmpty(jsonResponse)) {
            return null;
        }

        List<NewsModelClass> fetchedNewsList = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(jsonResponse);
            JSONObject jsonObject1 = jsonObject.getJSONObject("response");
            JSONArray jsonArray = jsonObject1.getJSONArray("results");

            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject jsonObject2 = jsonArray.optJSONObject(i);
                String newsSection = jsonObject2.optString("sectionName");
                String newsTitle = jsonObject2.optString("webTitle");
                String weburl = jsonObject2.optString("webUrl");
                String newsDate = jsonObject2.optString("webPublicationDate");
                String author = "";

                JSONArray tagsArray = jsonObject2.getJSONArray("tags");

                for (int j = 0; j < tagsArray.length(); j++) {
                    JSONObject tagsObject = tagsArray.getJSONObject(j);
                    author = tagsObject.optString("webTitle");
                }



                fetchedNewsList.add(new NewsModelClass(newsTitle, author, newsDate, newsSection, weburl));

            }
        } catch (JSONException e) {
        }
        return fetchedNewsList;
    }
}

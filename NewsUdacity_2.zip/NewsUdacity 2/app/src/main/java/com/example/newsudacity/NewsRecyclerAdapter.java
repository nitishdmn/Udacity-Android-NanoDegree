package com.example.newsudacity;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class NewsRecyclerAdapter extends RecyclerView.Adapter<NewsRecyclerAdapter.MyViewHolder> {

    List<NewsModelClass> list;
    private Context context;
    private ItemClickListener itemClickListener;

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView title;
        TextView section;
        TextView date;
        TextView author;
        LinearLayout mainLayout;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title_text_view);
            author = itemView.findViewById(R.id.author_text_view);
            section = itemView.findViewById(R.id.section_text_view);
            date = itemView.findViewById(R.id.date_text_view);
            mainLayout = itemView.findViewById(R.id.main_layout);

            mainLayout.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (itemClickListener != null) {
                itemClickListener.openNews(v, getAdapterPosition());
            }
        }
    }


    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }


    public NewsRecyclerAdapter(Context context, List<NewsModelClass> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public NewsRecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.news_item_layout, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsRecyclerAdapter.MyViewHolder myViewHolder, int i) {
        NewsModelClass modelClass = list.get(i);
        myViewHolder.title.setText(modelClass.getNewsTitle());
        myViewHolder.section.setText(modelClass.getNewsSection());
        myViewHolder.author.setText(modelClass.getNewsAuthor());
        myViewHolder.date.setText(modelClass.getNewsDate());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

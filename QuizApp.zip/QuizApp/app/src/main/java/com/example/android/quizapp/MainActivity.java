package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int mark = 0;

    String myString = " Result ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void submitOrder(View view) {
        mark=0;
        myString = " Result ";


        RadioButton line12 = (RadioButton) findViewById(R.id.line12);
        boolean hasline12 = line12.isChecked();

        if (hasline12) {
            mark++;
        }
        RadioButton line21 = (RadioButton) findViewById(R.id.line21);
        boolean hasline21 = line21.isChecked();

        if (hasline21) {
            mark++;
        }
        RadioButton line34 = (RadioButton) findViewById(R.id.line34);
        boolean hasline34 = line34.isChecked();

        if (hasline34) {
            mark++;
        }
        RadioButton line42 = (RadioButton) findViewById(R.id.line42);
        boolean hasline42 = line42.isChecked();

        if (hasline42) {
            mark++;
        }
        RadioButton line53 = (RadioButton) findViewById(R.id.line53);
        boolean hasline53 = line53.isChecked();

        if (hasline53) {
            mark++;
        }
        CheckBox line61 = (CheckBox) findViewById(R.id.line61);
        boolean hasline61 = line61.isChecked();

        CheckBox line62 = findViewById(R.id.line62);
        CheckBox line64 = findViewById(R.id.line64);

        boolean hasLine62 = line62.isChecked();
        boolean hasLine64 = line64.isChecked();

        CheckBox line63 = (CheckBox) findViewById(R.id.line63);
        boolean hasline63 = line63.isChecked();
        if (hasline61 && hasline63 && !hasLine62 && !hasLine64) {
            mark++;
        }
        EditText text = (EditText) findViewById(R.id.Edit);
        String name = text.getText().toString();

        Log.v("MainActivity", " true" + name);

        String str = new String("constructor");
        if (str.compareToIgnoreCase(name) == 0) {
            mark++;

        }
        myString += mark;


        Toast.makeText(getApplicationContext(), myString, Toast.LENGTH_LONG).show();

    }

    public void reset(View view) {
        mark = 0;
        EditText editText = findViewById(R.id.Edit);
        editText.setText("");
        CheckBox checkBox = findViewById(R.id.line61);
        checkBox.setChecked(false);
        checkBox = findViewById(R.id.line62);
        checkBox.setChecked(false);
        checkBox = findViewById(R.id.line63);
        checkBox.setChecked(false);
        checkBox = findViewById(R.id.line64);
        checkBox.setChecked(false);

        RadioGroup radioGroup = findViewById(R.id.group1);
        radioGroup.clearCheck();
        radioGroup = findViewById(R.id.group2);
        radioGroup.clearCheck();
        radioGroup = findViewById(R.id.group3);
        radioGroup.clearCheck();
        radioGroup = findViewById(R.id.group4);
        radioGroup.clearCheck();
        radioGroup = findViewById(R.id.group5);
        radioGroup.clearCheck();


    }
}

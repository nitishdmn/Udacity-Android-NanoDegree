package com.example.tourguideapp;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class CustomAdapter extends FragmentPagerAdapter {
    Context context;

    public CustomAdapter(FragmentManager fragmentManager, Context context)
    {

        super(fragmentManager);
        this.context = context;
    }

    @Override
    public Fragment getItem(int i) {
        Fragment fragment = null;
        if(i == 0)
        {
            fragment = new EventFragment();
        }
        else if(i == 1)
        {
            fragment = new HistoricalFragment();
        }
        else if(i == 2)
        {
            fragment = new TouristSpotFragment();
        }
        else if(i == 3)
        {
            fragment = new RestaurantFragment();
        }

        return fragment;
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title = null;
        if(position == 1)
        {
            title = context.getString(R.string.his_places);
        }
        else if(position == 0)
        {
            title = context.getString(R.string.events);
        }
        else if(position == 2)
        {
            title = context.getString(R.string.tourist_spot);
        }
        else if(position == 3)
        {
            title = context.getString(R.string.restaurant);
        }

        return title;
    }
}

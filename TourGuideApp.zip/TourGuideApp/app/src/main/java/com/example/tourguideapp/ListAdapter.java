package com.example.tourguideapp;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.MyViewHolder> {

    private List<ModelClass> list;

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        ImageView imageView;
        TextView titleTextView;
        TextView desTextView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.sample_image_view);
            titleTextView = itemView.findViewById(R.id.sample_text_view);
            desTextView = itemView.findViewById(R.id.des_text_view);
        }
    }

    public ListAdapter(List<ModelClass> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_layout, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListAdapter.MyViewHolder myViewHolder, int i) {
        ModelClass modelClass = list.get(i);
        myViewHolder.imageView.setImageResource(modelClass.getImageRes());
        myViewHolder.titleTextView.setText(modelClass.getName());
        myViewHolder.desTextView.setText(modelClass.getDes());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}

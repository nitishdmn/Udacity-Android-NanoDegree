package com.example.tourguideapp;

public class ModelClass {
    int imageRes;
    String name;
    String des;

    public ModelClass() {
    }

    public ModelClass(int imageRes, String name, String des) {
        this.imageRes = imageRes;
        this.name = name;
        this.des = des;
    }

    public int getImageRes() {
        return imageRes;
    }

    public void setImageRes(int imageRes) {
        this.imageRes = imageRes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}

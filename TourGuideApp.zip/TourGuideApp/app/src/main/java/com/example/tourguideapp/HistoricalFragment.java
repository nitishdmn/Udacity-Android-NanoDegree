package com.example.tourguideapp;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class HistoricalFragment extends Fragment {

    private List<ModelClass> list = new ArrayList<>();
    ListAdapter listAdapter;
    RecyclerView recyclerView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_historical_fragment, null);

        prepareData();
        recyclerView = view.findViewById(R.id.historical_recycler_view);

        listAdapter = new ListAdapter(list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity().getBaseContext()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(listAdapter);


        return view;
    }

    private void prepareData() {
        ModelClass modelClass = new ModelClass(R.drawable.h1, getString(R.string.h1), getString(R.string.h11));
        list.add(modelClass);

        modelClass = new ModelClass(R.drawable.h2, getString(R.string.h2), getString(R.string.h22));
        list.add(modelClass);

        modelClass = new ModelClass(R.drawable.h3, getString(R.string.h3), getString(R.string.h33));
        list.add(modelClass);

        modelClass = new ModelClass(R.drawable.h4, getString(R.string.h4), getString(R.string.h44));
        list.add(modelClass);

        modelClass = new ModelClass(R.drawable.h5, getString(R.string.h5), getString(R.string.h55));
        list.add(modelClass);
    }
}

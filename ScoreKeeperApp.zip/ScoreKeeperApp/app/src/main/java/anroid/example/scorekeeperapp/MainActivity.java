package anroid.example.scorekeeperapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {


    int quantity = 0, count = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void incrementA(View view) {
        quantity = quantity + 1;

        displayA(quantity);
    }

    public void incrementA1(View view) {
        quantity = quantity + 2;

        displayA(quantity);
    }

    public void decrementA(View view) {
        quantity = quantity - 1;

        displayA(quantity);
    }


    public void incrementB(View view) {
        count = count + 1;

        displayB(count);
    }

    public void incrementB2(View view) {
        count = count + 2;

        displayB(count);
    }

    public void decrementB(View view) {
        count = count - 1;

        displayB(count);
    }

    public void resetScore(View view){
      quantity = 0;
      count=0;
      displayA(quantity);
      displayB(count);
    }



    private void displayA(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.scoreA);
        quantityTextView.setText("" + number);

    }
        private void displayB ( int number){
            TextView countTextView = (TextView) findViewById(R.id.scoreB);
            countTextView.setText("" + number);
        }


}